const SESSION_DAYS = 7;
const encoder = new TextEncoder();

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers }
  });
}

function randomHex(bytes = 24) {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  return [...data].map(x => x.toString(16).padStart(2, "0")).join("");
}

async function sha256(value) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}

async function passwordHash(password, saltHex) {
  const salt = Uint8Array.from(saltHex.match(/.{2}/g), x => parseInt(x, 16));
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 210000, hash: "SHA-256" }, key, 256
  );
  return [...new Uint8Array(bits)].map(x => x.toString(16).padStart(2, "0")).join("");
}

function cookie(name, value, maxAge) {
  return `${name}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;
}

function getCookie(request, name) {
  const raw = request.headers.get("Cookie") || "";
  const part = raw.split(";").map(x => x.trim()).find(x => x.startsWith(name + "="));
  return part ? part.slice(name.length + 1) : null;
}

async function currentUser(request, env) {
  const token = getCookie(request, "tnt_session");
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT users.id, users.name, users.email
     FROM sessions JOIN users ON users.id = sessions.user_id
     WHERE sessions.token_hash = ? AND sessions.expires_at > ?`
  ).bind(tokenHash, Math.floor(Date.now() / 1000)).first();
  return row || null;
}

function validEmail(email) {
  return typeof email === "string" && email.length <= 254 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validDestination(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) && url.hostname.includes(".");
  } catch { return false; }
}

async function api(request, env, path) {
  if (request.method === "POST" && path === "/api/register") {
    const body = await request.json().catch(() => ({}));
    const name = String(body.name || "").trim().slice(0, 80);
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (name.length < 2 || !validEmail(email) || password.length < 10 || password.length > 128)
      return json({ error: "Informe nome, e-mail válido e senha com pelo menos 10 caracteres." }, 400);
    const salt = randomHex(16);
    const hash = await passwordHash(password, salt);
    const id = crypto.randomUUID();
    try {
      await env.DB.prepare("INSERT INTO users (id, name, email, password_hash, password_salt) VALUES (?, ?, ?, ?, ?)")
        .bind(id, name, email, hash, salt).run();
    } catch {
      return json({ error: "Não foi possível criar a conta. Esse e-mail pode já estar cadastrado." }, 409);
    }
    return json({ ok: true, message: "Conta criada. Agora entre com seu e-mail e senha." }, 201);
  }

  if (request.method === "POST" && path === "/api/login") {
    const body = await request.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    const user = await env.DB.prepare("SELECT * FROM users WHERE email = ?").bind(email).first();
    if (!user) return json({ error: "E-mail ou senha incorretos." }, 401);
    const candidate = await passwordHash(password, user.password_salt);
    if (candidate !== user.password_hash) return json({ error: "E-mail ou senha incorretos." }, 401);
    const token = randomHex(32);
    const expiry = Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400;
    await env.DB.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)")
      .bind(await sha256(token), user.id, expiry).run();
    return json({ ok: true, user: { name: user.name, email: user.email } }, 200, {
      "set-cookie": cookie("tnt_session", token, SESSION_DAYS * 86400)
    });
  }

  if (request.method === "POST" && path === "/api/logout") {
    const token = getCookie(request, "tnt_session");
    if (token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256(token)).run();
    return json({ ok: true }, 200, { "set-cookie": cookie("tnt_session", "", 0) });
  }

  if (request.method === "GET" && path === "/api/me") {
    const user = await currentUser(request, env);
    return user ? json({ user }) : json({ user: null }, 401);
  }

  if (request.method === "POST" && path === "/api/forgot-password") {
    const body = await request.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase();
    if (!validEmail(email)) return json({ error: "Informe um e-mail válido." }, 400);
    const user = await env.DB.prepare("SELECT id FROM users WHERE email = ?").bind(email).first();
    // Sempre responde da mesma forma para não revelar se um e-mail tem cadastro.
    if (user) {
      const token = randomHex(32);
      await env.DB.prepare("INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?, ?, ?)")
        .bind(await sha256(token), user.id, Math.floor(Date.now() / 1000) + 1800).run();
      // TODO: enviar URL de redefinição por provedor de e-mail. Nunca expor token na resposta.
    }
    return json({ ok: true, message: "Se houver uma conta com esse e-mail, enviaremos instruções quando o envio de e-mail estiver configurado." });
  }

  if (request.method === "POST" && path === "/api/links") {
    const user = await currentUser(request, env);
    if (!user) return json({ error: "Entre na sua conta para continuar." }, 401);
    const body = await request.json().catch(() => ({}));
    const destination = String(body.url || "").trim();
    if (!validDestination(destination)) return json({ error: "Informe um endereço HTTP ou HTTPS válido." }, 400);
    const code = randomHex(4);
    const id = crypto.randomUUID();
    await env.DB.prepare("INSERT INTO links (id, user_id, code, destination_url) VALUES (?, ?, ?, ?)")
      .bind(id, user.id, code, destination).run();
    const base = (env.APP_BASE_URL || new URL(request.url).origin).replace(/\/$/, "");
    return json({ ok: true, shortUrl: `${base}/${code}` }, 201);
  }

  if (request.method === "GET" && path === "/api/links") {
    const user = await currentUser(request, env);
    if (!user) return json({ error: "Entre na sua conta para continuar." }, 401);
    const result = await env.DB.prepare(
      "SELECT code, destination_url, clicks, created_at FROM links WHERE user_id = ? ORDER BY created_at DESC LIMIT 100"
    ).bind(user.id).all();
    return json({ links: result.results || [] });
  }

  return json({ error: "Rota não encontrada." }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return api(request, env, url.pathname);

    const code = url.pathname.slice(1);
    if (code && !code.includes("/")) {
      const link = await env.DB.prepare(
        "SELECT id, destination_url FROM links WHERE code = ? AND is_active = 1"
      ).bind(code).first();
      if (link) {
        await env.DB.prepare("UPDATE links SET clicks = clicks + 1 WHERE id = ?").bind(link.id).run();
        const interstitial = new URL("/go.html", url.origin);
        interstitial.searchParams.set("to", link.destination_url);
        return Response.redirect(interstitial.toString(), 302);
      }
    }
    return env.ASSETS.fetch(request);
  }
};
